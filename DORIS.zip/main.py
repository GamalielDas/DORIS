import os

os.system('python ..\\test.py')
# os.system('Without_GUI.exe')
int(input())